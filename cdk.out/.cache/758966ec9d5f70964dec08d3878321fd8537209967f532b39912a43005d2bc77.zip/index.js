const aws = require('aws-sdk');
const cd = require('content-disposition');
const {v4: uuidv4} = require('uuid');
const s3 = new aws.S3({ apiVersion: '2006-03-01' });
const bucket = process.env.bucket;
const CDN = process.env.CDN; 
const appId = process.env.appId;
const path = require('path');

exports.handler = async (event) => {
    // console.log('## ENVIRONMENT VARIABLES: ' + JSON.stringify(process.env))
    // console.log('## EVENT: ' + JSON.stringify(event))
    
    const body = Buffer.from(event["body-json"], "base64");
    // console.log('## EVENT: ' + JSON.stringify(event.params))
    // console.log('## EVENT: ' + JSON.stringify(event.context))

    var id, timestamp, ext, key;  
    var fileName="", downUrlName="";

    var contentType;
    if(event.params.header['Content-Type']) {
        contentType = event.params.header["Content-Type"];
    } 
    else if(event.params.header['content-type']) {
        contentType = event.params.header["content-type"];
    }
    // console.log('contentType = '+contentType); 

    var contentDisposition;
    if(event.params.header['Content-Disposition']) {
        contentDisposition = event.params.header["Content-Disposition"];  
    } 
    else if(event.params.header['content-disposition']) {
        contentDisposition = event.params.header["content-disposition"];  
    }
    // console.log('disposition = '+contentDisposition);

    if(contentDisposition) {
      fileName = cd.parse(contentDisposition).parameters.filename;

      ext = path.parse(fileName).ext;
    }

    if(!ext) {
      if(contentType == 'image/jpeg') ext = '.jpeg';
      else if(contentType == 'image/jpg') ext = '.jpg';
      else if(contentType == 'image/png') ext = '.png';
      else ext = '.jpeg';  // default
    }
    // console.log('ext: ', ext);

    id = uuidv4(); // generate uuid
    key = id+ext;
    if(!fileName) {
        fileName = id+ext;
    } 
    downUrlName = CDN+fileName;

    // putObject to S3
    console.log('start upload: ' + id);
    try {
        const destparams = {
            Bucket: bucket, 
            Key: key,  // use uuid for filename in order to escape duplicated filename 
            Body: body,
            ContentType: contentType
        };
        const {putResult} = await s3.putObject(destparams).promise(); 
  
        console.log('finish upload: ' + id);
    } catch (error) {
        console.log(error);
        return;
    } 

    var senderAddress = "storytimebot21@gmail.com"; // check later
    var toAddress = "storytimebot21@gmail.com";
    var subject = "Amazon Pinpoint (AWS SDK for JavaScript in Node.js)";
    var body_text = `Amazon Pinpoint Test (SDK for JavaScript in Node.js)
    ----------------------------------------------------
    This email was sent with Amazon Pinpoint using the AWS SDK for JavaScript in Node.js.
    For more information, see https:\/\/aws.amazon.com/sdk-for-node-js/`;
    
    // The body of the email for recipients whose email clients support HTML content.
    var body_html = `<html>
    <head></head>
    <body>
      <h1>Amazon Pinpoint Test (SDK for JavaScript in Node.js)</h1>
      <p>This email was sent with
        <a href='https://aws.amazon.com/pinpoint/'>the Amazon Pinpoint API</a> using the
        <a href='https://aws.amazon.com/sdk-for-node-js/'>
          AWS SDK for JavaScript in Node.js</a>.</p>
    </body>
    </html>`;

    var charset = "UTF-8";
//    var credentials = new aws.SharedIniFileCredentials({profile: 'default'});
//    aws.config.credentials = credentials;
//    aws.config.update({region:aws_region});

    var pinpoint = new aws.Pinpoint();

    var pinPointParams = {
        ApplicationId: appId,
        MessageRequest: {
            Addresses: {
                [toAddress]:{
                    ChannelType: 'EMAIL'
                }
            },
            MessageConfiguration: {
                EmailMessage: {
                    FromAddress: senderAddress,
                    SimpleEmail: {
                        Subject: {
                            Charset: charset,
                            Data: subject
                        },
                        HtmlPart: {
                            Charset: charset,
                            Data: body_html
                        },
                        TextPart: {
                            Charset: charset,
                            Data: body_text
                        }
                    }
                }
            }
        }
    };

    pinpoint.sendMessages(pinPointParams, function(err, data) {
        if(err) {
          console.log(err.message);
        } else {
          console.log("Email sent! Message ID: ", data['MessageResponse']['Result'][toAddress]['MessageId']);
        }

        // for return info
        const fileInfo = {
            Bucket: bucket,
            Key: key,
            Name: fileName,
            ID: id,
            ContentType: contentType,
            downUrlName: downUrlName,
        }; 
        // console.log('file info: ' + JSON.stringify(fileInfo)) 

        const response = {
            statusCode: 200,
            headers: {
            'ETag': id,
            'Timestamp': timestamp
            },
            body: JSON.stringify(fileInfo)
        };
        return response;
    });

    function wait(){
        return new Promise((resolve, reject) => {
            setTimeout(() => resolve("hello"), 2000)
        });
      }
      console.log(await wait());
      console.log(await wait());
      console.log(await wait());
      console.log(await wait());
      console.log(await wait());
      
      return 'exiting'
     

};