# lambda-producer
It is a lamda function for producer with pinpoint
